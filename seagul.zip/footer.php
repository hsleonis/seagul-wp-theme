<?php
/**
 * Seagul Theme Footer
 *
 * @package     TMXSeagul
 * @author      Md. Hasan Shahriar <info@themeaxe.com>
 * @since       1.0.1
 */
?>
    <?php wp_footer(); ?>
    </body>
</html>
