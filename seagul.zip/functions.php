<?php
/**
 * Seagul Theme Functions
 *
 * @package     TMXSeagul
 * @author      Md. Hasan Shahriar <info@themeaxe.com>
 * @since       1.0.1
 */

require_once ('lib/inc.php');
TmxLibraryIncluder::instance('tmx-seagul');