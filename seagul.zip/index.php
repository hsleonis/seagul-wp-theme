<?php
/**
 * Seagul Theme Index
 *
 * @package     TMXSeagul
 * @author      Md. Hasan Shahriar <info@themeaxe.com>
 * @since       1.0.1
 */

    get_template_part('page', 'full-window');